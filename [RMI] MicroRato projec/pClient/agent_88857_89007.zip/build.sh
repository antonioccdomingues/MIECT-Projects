#!/bin/bash

# How to build your project

# Possibility for cpp agents
# make mainC4 

# Possibility for java agents
# javac mainC4.java

# Possibility for python agents
# nothing


