import sys, socket, csv, json

def client():
	tcp_s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	tcp_s.bind( ("0.0.0.0", 0) )
	tcp_s.connect(("193.136.92.147", 8080))
	con_data = "CONNECT\n"
	b_data = con_data.encode("utf-8")
	tcp_s.send(b_data)
	recv_data = tcp_s.recv(4096)
	data = recv_data.decode("utf-8")
	print(data)
	dict_token = json.loads(data)
	read_data = ("READ "+str(dict_token['TOKEN'])+"\n")
	r_data = read_data.encode("utf-8")
	tcp_s.send(r_data)
	json_data = tcp_s.recv(4096)
	j_data = json_data.decode("utf-8")
	data_csv = open("file.csv", "w", newline="")
	writer = csv.DictWriter(data_csv, delimiter=";", fieldnames=["Wind","Temperature","Humidity"])
	writer.writeheader()
	
	print(j_data)
	i=0
	while i<5:
		data = tcp_s.recv(4096)
		j_data = data.decode("utf-8")
		print(j_data)
		json_data=json.loads(j_data)
		wind=json_data["WIND"]
		
		json_data=json.loads(j_data)
		temperature=json_data["TEMPERATURE"]
		
		json_data=json.loads(j_data)
		humidity=json_data["HUMIDITY"]
		if (temperature >= 25):
			print("levar T-Shirt e calções ")
			
		if (temperature < 25 and temperature>15):
			print("levar calças e camisola")
			
		if (wind > 20 and wind< 50):
			print("Levar casaco")
			
		if (humidity> 90 ):
			print("possibilidade de chuva")
			
		writer.writerow({"Wind":wind,"Temperature":temperature,"Humidity":humidity})
		i=i+1
	data_csv.close()
	tcp_s.close()
client()
	
